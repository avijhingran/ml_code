INSERT INTO CUSTOMER_TABLE (ID, NAME, ADDRESS, STATUS) VALUES
('C1234', 'John Smith', '123 Elm St', 'A'),
('C2345', 'Jane Doe', '456 Oak St', 'A');
